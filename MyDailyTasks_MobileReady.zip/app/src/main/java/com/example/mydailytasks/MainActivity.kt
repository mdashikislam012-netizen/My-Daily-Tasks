package com.example.mydailytasks

import android.app.*
import android.content.*
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.*

data class Task(
    val id: Long,
    val title: String,
    val time: Long,
    val done: Boolean = false
)

object TaskStore {
    private const val PREF = "tasks"
    private const val KEY = "data"

    fun load(context: Context): MutableList<Task> {
        val raw = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "") ?: ""
        if (raw.isBlank()) return mutableListOf()
        return raw.split("\n").mapNotNull { line ->
            val p = line.split("\u001F")
            if (p.size >= 4) Task(p[0].toLongOrNull() ?: return@mapNotNull null,
                p[1], p[2].toLongOrNull() ?: return@mapNotNull null, p[3] == "1") else null
        }.toMutableList()
    }

    fun save(context: Context, tasks: List<Task>) {
        val raw = tasks.joinToString("\n") {
            "${it.id}\u001F${it.title.replace("\n"," ")}\u001F${it.time}\u001F${if (it.done) "1" else "0"}"
        }
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, raw).apply()
    }
}

object ReminderScheduler {
    fun schedule(context: Context, task: Task) {
        if (task.time <= System.currentTimeMillis() || task.done) return
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra("id", task.id)
            putExtra("title", task.title)
        }
        val pi = PendingIntent.getBroadcast(
            context, task.id.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        if (android.os.Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, task.time, pi)
        } else {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, task.time, pi)
        }
    }

    fun cancel(context: Context, task: Task) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ReminderReceiver::class.java)
        val pi = PendingIntent.getBroadcast(
            context, task.id.hashCode(), intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        pi?.let { am.cancel(it); it.cancel() }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val channelId = "daily_tasks"
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (android.os.Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                channelId, "কাজের রিমাইন্ডার",
                NotificationManager.IMPORTANCE_HIGH
            )
            channel.enableVibration(true)
            nm.createNotificationChannel(channel)
        }

        val title = intent.getStringExtra("title") ?: "আপনার একটি কাজ আছে"
        val openIntent = Intent(context, MainActivity::class.java)
        val pi = PendingIntent.getActivity(
            context, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = if (android.os.Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(context, channelId)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("আমার প্রতিদিনের কাজ")
                .setContentText(title)
                .setAutoCancel(true)
                .setContentIntent(pi)
                .build()
        } else {
            Notification.Builder(context)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("আমার প্রতিদিনের কাজ")
                .setContentText(title)
                .setAutoCancel(true)
                .setContentIntent(pi)
                .build()
        }
        nm.notify(intent.getLongExtra("id", 0L).hashCode(), notification)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            TaskStore.load(context).filter { !it.done && it.time > System.currentTimeMillis() }
                .forEach { ReminderScheduler.schedule(context, it) }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DailyTasksApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DailyTasksApp() {
    val context = LocalContext.current
    var tasks by remember { mutableStateOf(TaskStore.load(context)) }
    var showAdd by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            (context as? Activity)?.requestPermissions(
                arrayOf("android.permission.POST_NOTIFICATIONS"), 100
            )
        }
    }

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("আমার প্রতিদিনের কাজ") }) },
            floatingActionButton = {
                FloatingActionButton(onClick = { showAdd = true }) { Text("+") }
            }
        ) { padding ->
            if (tasks.isEmpty()) {
                Column(
                    Modifier.fillMaxSize().padding(padding).padding(24.dp),
                    verticalArrangement = Arrangement.Center
                ) {
                    Text("আজকের কোনো কাজ যোগ করা হয়নি।", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Text("নিচের + বাটনে চাপ দিয়ে কাজ ও রিমাইন্ডারের সময় দিন।")
                }
            } else {
                LazyColumn(
                    Modifier.fillMaxSize().padding(padding).padding(horizontal = 12.dp)
                ) {
                    items(tasks, key = { it.id }) { task ->
                        TaskRow(
                            task = task,
                            onDone = {
                                val updated = tasks.map {
                                    if (it.id == task.id) it.copy(done = !it.done) else it
                                }
                                tasks = updated.toMutableList()
                                TaskStore.save(context, tasks)
                                if (!task.done) ReminderScheduler.cancel(context, task)
                                else ReminderScheduler.schedule(context, task)
                            },
                            onDelete = {
                                ReminderScheduler.cancel(context, task)
                                tasks = tasks.filterNot { it.id == task.id }.toMutableList()
                                TaskStore.save(context, tasks)
                            }
                        )
                    }
                }
            }
        }

        if (showAdd) {
            AddTaskDialog(
                onDismiss = { showAdd = false },
                onAdd = { title, millis ->
                    val task = Task(System.currentTimeMillis(), title, millis)
                    tasks = (tasks + task).toMutableList()
                    TaskStore.save(context, tasks)
                    ReminderScheduler.schedule(context, task)
                    showAdd = false
                }
            )
        }
    }
}

@Composable
fun TaskRow(task: Task, onDone: () -> Unit, onDelete: () -> Unit) {
    val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
    Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Row(Modifier.fillMaxWidth().padding(12.dp)) {
            Checkbox(checked = task.done, onCheckedChange = { onDone() })
            Column(Modifier.weight(1f).padding(top = 4.dp)) {
                Text(task.title, style = MaterialTheme.typography.titleMedium)
                Text(sdf.format(Date(task.time)), style = MaterialTheme.typography.bodySmall)
            }
            TextButton(onClick = onDelete) { Text("মুছুন") }
        }
    }
}

@Composable
fun AddTaskDialog(onDismiss: () -> Unit, onAdd: (String, Long) -> Unit) {
    val context = LocalContext.current
    var title by remember { mutableStateOf("") }
    val cal = remember { Calendar.getInstance().apply { add(Calendar.MINUTE, 5) } }
    var selected by remember { mutableStateOf(cal.timeInMillis) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("নতুন কাজ যোগ করুন") },
        text = {
            Column {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("কাজের নাম") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                Button(onClick = {
                    val c = Calendar.getInstance().apply { timeInMillis = selected }
                    DatePickerDialog(
                        context,
                        { _, y, m, d ->
                            c.set(Calendar.YEAR, y); c.set(Calendar.MONTH, m); c.set(Calendar.DAY_OF_MONTH, d)
                            selected = c.timeInMillis
                        },
                        c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)
                    ).show()
                }) { Text("তারিখ নির্বাচন") }

                Button(onClick = {
                    val c = Calendar.getInstance().apply { timeInMillis = selected }
                    TimePickerDialog(
                        context,
                        { _, h, min ->
                            c.set(Calendar.HOUR_OF_DAY, h); c.set(Calendar.MINUTE, min); c.set(Calendar.SECOND, 0)
                            selected = c.timeInMillis
                        },
                        c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), false
                    ).show()
                }) { Text("সময় নির্বাচন") }

                Text(
                    "নির্ধারিত: " + SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.getDefault()).format(Date(selected)),
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        },
        confirmButton = {
            TextButton(enabled = title.isNotBlank() && selected > System.currentTimeMillis(),
                onClick = { onAdd(title.trim(), selected) }) { Text("যোগ করুন") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}
